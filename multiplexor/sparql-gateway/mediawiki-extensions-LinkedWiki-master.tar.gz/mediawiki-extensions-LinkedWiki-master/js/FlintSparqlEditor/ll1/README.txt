SWI-Prolog code used to precompute LL(1) parser tables from SPARQL grammar.
Ignore this unless you are modifying the grammar.
