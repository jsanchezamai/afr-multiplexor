<?php
/**
 * @copyright (c) 2019 Bourdercloud.com
 * @author Karima Rafes <karima.rafes@bordercloud.com>
 * @link https://www.mediawiki.org/wiki/Extension:LinkedWiki
 * @license CC-by-sa V4.0
 */

class ToolsParser
{
    public static function parserQuery($query,$parser) {
        $res = $query;
        if (preg_match("/<PAGEIRI>/i",$res)) {
            $uri  = "<".ToolsParser::pageIri($parser).">";
            $res  = str_replace("<PAGEIRI>",$uri , $res);
        }
        return $res;
    }

    public static function  pageIri(&$parser) {
        //$resolverurl = $parser->getTitle()->getFullURL();
        $resolverurl = urldecode($parser->getTitle()->getSubjectPage()->getFullURL());
        return $resolverurl;
    }

    public static function  newEndpoint($config,$endpoint) {
       // GLOBAL $wgLinkedWikiAccessEndpoint,$wgLinkedWikiConfigDefault;
        $errorMessage = null;
        $objConfig = null;

        $errorMessage = "" ;

        try {
            if(! EMPTY($endpoint)){
                $objConfig = new LinkedWikiConfig();
                //$objConfig->setEndpoint($endpoint);
                $objConfig->setEndpointRead($endpoint);
            }elseif(! EMPTY($config)){
                $objConfig = new LinkedWikiConfig($config);
            }else{
                $objConfig = new LinkedWikiConfig();
            }
        } catch (Exception $e) {
            $errorMessage =  $e->getMessage();
            return array('endpoint'=> $endpoint, 'errorMessage' => $errorMessage);
        }

        $objConfig->setReadOnly(true);
        $endpoint =$objConfig->getInstanceEndpoint();

        return array('endpoint'=> $endpoint, 'errorMessage' => $errorMessage);
    }
}
