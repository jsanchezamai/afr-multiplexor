// Google Api key
// Todo put the link of tutorial to create a new key
var googleApiKey = "GOOGLE_MAP_API_KEY";

// OpenStreetMap Access Token
// Todo put the link of tutorial to create a new token
var osmAccessToken = "OPENSTREETMAP_ACCESS_TOKEN";
